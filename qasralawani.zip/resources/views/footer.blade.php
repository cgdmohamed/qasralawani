<!-- resources/views/layouts/footer.blade.php -->
<footer class="text-center py-3 mt-5 opacity-25">
    <p>&copy; {{ date('Y') }} قصر الاواني. {{ __('messages.all_rights_reserved') }}</p>
</footer>
