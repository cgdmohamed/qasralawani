@extends('layouts.app')

@section('content')
<div class="row justify-content-center">
    <div class="col-md-6 text-center">

        <h3>Coupon Already Claimed</h3>
        <div class="alert alert-info">
            You have already received a coupon code. Please check your SMS messages.
        </div>

    </div>
</div>
@endsection
