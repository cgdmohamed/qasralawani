<?php $__env->startSection('content'); ?>
    <div class="box p-2 text-light rounded">
        <div class=" p-2 mb-3">
            <h1 class="text-center fw-bold">
                <?php echo e(__('messages.gift_for_you')); ?>

            </h1>
            <p class="lead text-center fs-2">
                <?php echo e(__('messages.enter_your_phone_number_and_receive')); ?>

                <br>
                <strong class="fw-bold"><?php echo e(__('messages.15_discount_code')); ?></strong>
            </p>
        </div>
        <div class="row justify-content-center">
            <div class="col-md-6">

                <?php if($errors->any()): ?>
                    <div class="alert alert-danger">
                        <ul class="m-0">
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                <?php endif; ?>

                <form action="<?php echo e(route('otp.request')); ?>" method="POST">
                    <?php echo csrf_field(); ?>

                    <div class="mb-3">
                        <label for="name" class="form-label"></label>
                        <input type="text" name="name" id="name" class="form-control form-control-lg"
                            placeholder="<?php echo e(__('messages.name_placeholder')); ?>" value="<?php echo e(old('name')); ?>" required>
                    </div>

                    <div class="mb-3">
                        <label for="email" class="form-label"><?php echo e(__('messages.email')); ?></label>
                        <input type="email" name="email" id="email" class="form-control form-control-lg"
                            placeholder="<?php echo e(__('messages.email_placeholder')); ?>" value="<?php echo e(old('email')); ?>">
                    </div>

                    <div class="mb-3">
                        <label for="phone_number" class="form-label"><?php echo e(__('messages.phone')); ?></label>
                        <input type="text" name="phone_number" id="phone_number" class="form-control form-control-lg"
                            placeholder="<?php echo e(__('messages.phone_placeholder')); ?>" value="<?php echo e(old('phone_number')); ?>"
                            required>
                    </div>
                    <div class="box-footer rounded p-3">
                        <button type="submit"
                            class="btn btn-lg text-white fw-bold w-100 d-flex align-items-center justify-content-center"> <i
                                class="lni lni-phone"></i>
                            <?php echo e(__('messages.request_otp')); ?></button>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\qasralawani\resources\views/auth/phone.blade.php ENDPATH**/ ?>