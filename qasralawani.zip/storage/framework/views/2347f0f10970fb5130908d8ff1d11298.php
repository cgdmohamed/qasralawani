<?php $__env->startSection('content'); ?>
    <div class="row justify-content-center">
        <div class="col-md-6">
            <h3>Enter Your Details</h3>

            <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <ul class="m-0">
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>

            <form action="<?php echo e(route('otp.request')); ?>" method="POST">
                <?php echo csrf_field(); ?>

                <div class="mb-3">
                    <label for="name" class="form-label">Name</label>
                    <input type="text" name="name" id="name" class="form-control" placeholder="Your name"
                        value="<?php echo e(old('name')); ?>" required>
                </div>

                <div class="mb-3">
                    <label for="email" class="form-label">Email (optional)</label>
                    <input type="email" name="email" id="email" class="form-control"
                        placeholder="Your email address" value="<?php echo e(old('email')); ?>">
                </div>

                <div class="mb-3">
                    <label for="phone_number" class="form-label">Phone (KSA)</label>
                    <input type="text" name="phone_number" id="phone_number" class="form-control"
                        placeholder="05XXXXXXXX or +9665XXXXXXXX" value="<?php echo e(old('phone_number')); ?>" required>
                </div>

                <button type="submit" class="btn btn-primary">Request OTP</button>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\qasralawani\resources\views/auth/phone.blade.php ENDPATH**/ ?>