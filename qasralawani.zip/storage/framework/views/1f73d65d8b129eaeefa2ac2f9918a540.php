<?php $__env->startSection('content'); ?>
<div class="row justify-content-center">
    <div class="col-md-6 text-center">

        <h3 class="mb-4"><?php echo e(__('messages.congratulations')); ?></h3>
        <p><?php echo e(__('messages.your_coupon_code')); ?></p>
        <div class="alert alert-success display-5" role="alert">
            <strong><?php echo e($couponCode); ?></strong>
        </div>

        <p><?php echo e(__('messages.coupon_sent_sms')); ?></p>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\qasralawani\resources\views/coupon/show.blade.php ENDPATH**/ ?>