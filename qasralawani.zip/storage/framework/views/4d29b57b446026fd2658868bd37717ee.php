<?php $__env->startSection('content'); ?>
    <h2><?php echo e(__('messages.used_coupons')); ?></h2>
    <hr />
    <table class="table table-bordered">
        <thead>
            <tr>
                <th><?php echo e(__('messages.id')); ?></th>
                <th><?php echo e(__('messages.code')); ?></th>
                <th><?php echo e(__('messages.used_by_phone')); ?></th>
                <th><?php echo e(__('messages.used_at')); ?></th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $coupons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $coupon): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($coupon->id); ?></td>
                    <td><?php echo e($coupon->code); ?></td>
                    <td>
                        <?php echo e($coupon->subscriber ? $coupon->subscriber->phone_number : 'N/A'); ?>

                    </td>
                    <td><?php echo e($coupon->used_at); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="4"><?php echo e(__('messages.no_used_coupons')); ?></td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>

    <?php echo e($coupons->links()); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\qasralawani\resources\views/admin/successful_coupons.blade.php ENDPATH**/ ?>