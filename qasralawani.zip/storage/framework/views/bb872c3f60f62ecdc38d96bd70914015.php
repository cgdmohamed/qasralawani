<!-- resources/views/layouts/app.blade.php -->
<!DOCTYPE html>
<html lang="<?php echo e(app()->getLocale()); ?>" dir="<?php echo e(app()->getLocale() == 'ar' ? 'rtl' : 'ltr'); ?>">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title><?php echo e(__('messages.coupon_system')); ?></title>
    <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.min.css')); ?>">
    <link href="https://cdn.lineicons.com/5.0/lineicons.css" rel="stylesheet" />
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@200..1000&display=swap" rel="stylesheet" />
    <link rel="stylesheet" href="<?php echo e(asset('css/custom.css')); ?>">
</head>

<body>
    <nav class="navbar">
        <div class="container-fluid">
            <div class="row w-100">
                <div class="d-flex justify-content-between align-items-center">
                    <a class="navbar-brand" href="#"><img src="<?php echo e(asset('img/Logo.png')); ?>" class="w-75"
                            alt="Logo"></a>
                    <div class="language-switcher" onclick="switchLanguage()">
                        <?php if(app()->getLocale() == 'ar'): ?>
                            EN
                        <?php else: ?>
                            ع
                        <?php endif; ?>
                    </div>
                </div>
            </div>

        </div>
    </nav>

    <div class="container my-4">
        <?php echo $__env->yieldContent('content'); ?>
    </div>

    <script>
        function switchLanguage() {
            let currentLang = "<?php echo e(app()->getLocale()); ?>";
            let newLang = currentLang === "ar" ? "en" : "ar";
            window.location.href = "<?php echo e(route('language.switch', '')); ?>/" + newLang;
        }
    </script>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <!-- Include Footer -->
    <?php echo $__env->make('footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

</body>

</html>
<?php /**PATH C:\laragon\www\qasralawani\resources\views/layouts/app.blade.php ENDPATH**/ ?>