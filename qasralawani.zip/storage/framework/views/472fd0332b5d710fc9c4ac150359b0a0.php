<?php $__env->startSection('content'); ?>
<h2><?php echo e(__('messages.admin_dashboard')); ?></h2>
<hr/>

<div class="row mb-4">
    <div class="col-md-3">
        <div class="card text-white bg-info">
            <div class="card-header"><?php echo e(__('messages.total_users')); ?></div>
            <div class="card-body">
                <h5 class="card-title"><?php echo e($totalUsers); ?></h5>
            </div>
        </div>
    </div>

    <div class="col-md-3">
        <div class="card text-white bg-success">
            <div class="card-header"><?php echo e(__('messages.used_coupons')); ?></div>
            <div class="card-body">
                <h5 class="card-title"><?php echo e($usedCoupons); ?></h5>
            </div>
        </div>
    </div>

    <div class="col-md-3">
        <div class="card text-white bg-warning">
            <div class="card-header"><?php echo e(__('messages.unused_coupons')); ?></div>
            <div class="card-body">
                <h5 class="card-title"><?php echo e($unusedCoupons); ?></h5>
            </div>
        </div>
    </div>
</div>

<!-- Import & Export -->
<div class="row">
    <div class="col-md-6">
        <h4><?php echo e(__('messages.import_coupons')); ?></h4>
        <?php if(session('success')): ?>
            <div class="alert alert-success"><?php echo e(__('messages.success_message')); ?></div>
        <?php endif; ?>
        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul class="m-0">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <li><?php echo e(__('messages.error_message')); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>

        <form action="<?php echo e(route('admin.import.coupons')); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="mb-3">
                <label for="csv_file" class="form-label"><?php echo e(__('messages.csv_file_label')); ?></label>
                <input type="file" name="csv_file" id="csv_file" accept=".csv" class="form-control" required>
            </div>
            <button type="submit" class="btn btn-primary"><?php echo e(__('messages.import_button')); ?></button>
            <a href="<?php echo e(route('admin.demo.csv')); ?>" class="btn btn-info">
                <?php echo e(__('messages.download_demo_csv')); ?>

            </a>
        </form>

    </div>

    <div class="col-md-6">
        <h4><?php echo e(__('messages.export_coupons')); ?></h4>
        <a href="<?php echo e(route('admin.export.coupons')); ?>" class="btn btn-secondary">
            <?php echo e(__('messages.export_button')); ?>

        </a>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\qasralawani\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>