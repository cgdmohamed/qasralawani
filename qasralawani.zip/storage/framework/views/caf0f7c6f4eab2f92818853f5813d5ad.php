<?php $__env->startSection('content'); ?>
<div class="row justify-content-center">
    <div class="col-md-6">

        <h3><?php echo e(__('messages.enter_otp_code')); ?></h3>

        <!-- Error / success messages -->
        <?php if(session('error')): ?>
            <div class="alert alert-danger"><?php echo e(__('messages.error_message')); ?></div>
        <?php endif; ?>
        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul class="m-0">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>

        <!-- We assume 'phone_number' is stored in session or passed along. -->
        <form action="<?php echo e(route('otp.verify')); ?>" method="POST">
            <?php echo csrf_field(); ?>

            <input type="hidden" name="phone_number"
                   value="<?php echo e(session('phone_number') ?? old('phone_number')); ?>">

            <div class="mb-3">
                <label for="otp_code" class="form-label"><?php echo e(__('messages.otp_code')); ?></label>
                <input type="text" name="otp_code" id="otp_code"
                       class="form-control" required>
            </div>

            <button type="submit" class="btn btn-primary"><?php echo e(__('messages.verify_otp')); ?></button>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\qasralawani\resources\views/auth/otp.blade.php ENDPATH**/ ?>