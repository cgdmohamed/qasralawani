<?php $__env->startSection('content'); ?>
    <h2>Subscribers List</h2>

    <div class="mb-3">
        <a href="<?php echo e(route('admin.export.subscribers')); ?>" class="btn btn-info">
            Download Subscribers CSV
        </a>
    </div>

    <table class="table table-bordered">
        <thead>
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Email</th>
                <th>Phone Number</th>
                <th>Subscribed At</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $subscribers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subscriber): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($subscriber->id); ?></td>
                    <td><?php echo e($subscriber->name); ?></td>
                    <td><?php echo e($subscriber->email ?? 'N/A'); ?></td>
                    <td><?php echo e($subscriber->phone_number); ?></td>
                    <td><?php echo e($subscriber->created_at->format('Y-m-d H:i')); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="5">No subscribers found.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>

    <?php echo e($subscribers->links()); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\qasralawani\resources\views/admin/subscribers.blade.php ENDPATH**/ ?>