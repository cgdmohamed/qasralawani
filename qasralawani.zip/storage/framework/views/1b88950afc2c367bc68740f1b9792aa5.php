<!-- resources/views/layouts/footer.blade.php -->
<footer class="text-center py-3 mt-5 opacity-25">
    <p>&copy; <?php echo e(date('Y')); ?> قصر الاواني. <?php echo e(__('messages.all_rights_reserved')); ?></p>
</footer>
<?php /**PATH C:\laragon\www\qasralawani\resources\views/footer.blade.php ENDPATH**/ ?>